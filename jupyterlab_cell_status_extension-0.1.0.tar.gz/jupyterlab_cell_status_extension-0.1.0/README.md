# jupyterlab_cell_status_extension
JupyterLab extension to indicate current cell status
